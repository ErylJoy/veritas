package service

import (
	"//src/janus/internal/constants"
	"fmt"
)

func Hahaha() string {
	fmt.Printf(constants.Re)
	return "sad"
}
