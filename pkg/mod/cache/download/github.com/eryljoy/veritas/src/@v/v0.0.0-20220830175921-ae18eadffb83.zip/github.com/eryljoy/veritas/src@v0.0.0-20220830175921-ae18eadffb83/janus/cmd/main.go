package main

import (
	"fmt"

	"github.com/eryljoy/veritas/janus/internal/constants"
)

func main() {
	fmt.Println("Hello you")
}

func ReadFile() string {
	fmt.Println(constants.Re)
	return "perfect"
}
