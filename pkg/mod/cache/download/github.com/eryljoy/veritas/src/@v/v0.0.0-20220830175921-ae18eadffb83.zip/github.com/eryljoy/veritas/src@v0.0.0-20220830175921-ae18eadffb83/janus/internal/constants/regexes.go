package constants

const Re = `^(func|int|string|bool|float|int64|int32|int16|int8)`
