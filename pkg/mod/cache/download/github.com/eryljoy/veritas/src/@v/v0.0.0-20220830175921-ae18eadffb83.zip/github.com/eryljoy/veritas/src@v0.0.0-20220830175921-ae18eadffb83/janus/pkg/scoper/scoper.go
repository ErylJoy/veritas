package scoper

import (
	"regexp"
)

type symbolTable struct {
}

func Verify(depth int) {
	regexp.Compile(name_regex.Re)
}
